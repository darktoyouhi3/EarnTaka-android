package com.earntaka.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Story(val title: String, val genre: String, val synopsis: String, val sample: String)

private val stories = listOf(
    Story("অন্ধকার জগতের ইফরিত", "Mystery • Ifrit",
        "এক পরিত্যক্ত দুর্গের নিচে ঘুমিয়ে আছে এক ইফরিত; তার মুক্তির সঙ্গে জড়িয়ে আছে বহু শতাব্দীর অভিশাপ।",
        """ঝড়ের রাতে আরিফ পুরোনো দুর্গের নিচে একটি লোহার দরজা খুঁজে পেল। দরজার ওপাশ থেকে ভেসে এল ভারী কণ্ঠ—“মানুষ, তুমি কী চাও?” প্রদীপের শিখা নীল হয়ে উঠল। দেয়ালে লেখা ছিল: যে দরজা খুলবে, সে নিজের ছায়াকেই হারাবে। আরিফ বুঝল, বন্দি সত্তাটি সাধারণ কোনো জিন নয়—সে আগুনের রাজ্যের নির্বাসিত ইফরিত।"""),
    Story("মারিদ জিনের অভিশাপ", "Dark Fantasy • Marid",
        "সমুদ্রের গভীরে জেগে ওঠে এক প্রাচীন মারিদ। অভিশাপ ভাঙতে খুঁজে পেতে হবে হারানো মুক্তার সাতটি টুকরো।",
        """পূর্ণিমার রাতে সমুদ্র অস্বাভাবিকভাবে স্থির হয়ে গেল। নাবিক সামির জলের নিচে নীল আলো দেখে ঝুঁকতেই ঢেউয়ের বুক চিরে উঠে এল এক বিশাল অবয়ব। “আমার মুক্তা সাত খণ্ডে ভাঙা,” সে বলল। “প্রতিটি টুকরো পাহারা দেয় একেকটি স্মৃতি।” সামির জানত, এই যাত্রা তাকে সমুদ্রের চেয়েও গভীর এক রহস্যে নিয়ে যাবে।"""),
    Story("জান্নান: জিন সম্রাটের উত্থান", "Epic Fantasy • Jinn Empire",
        "সাত রাজ্যের ক্ষমতার দ্বন্দ্বে এক নির্বাসিত উত্তরাধিকারী আবিষ্কার করে তার ভেতরে লুকিয়ে থাকা সম্রাটের উত্তরাধিকার।",
        """সাত রাজ্যের আকাশে একই রাতে সাতটি ধূমকেতু দেখা দিল। নির্বাসিত জান্নানের হাতে তুলে দেওয়া হলো কালো মলাটের এক বই। তার পাতায় ফুটে উঠল সাত রাজ্যের মানচিত্র। “তোমার নাম শুধু নাম নয়,” বৃদ্ধ গ্রন্থরক্ষক বললেন, “এটি একটি সিংহাসনের চাবি।” কিন্তু মুকুটের সঙ্গে জড়িয়ে ছিল এক ভয়ংকর শপথ।"""),
    Story("ফেরেশতাদের শক্তির সমকক্ষ রহস্যময় জিন", "Cosmic Mystery • Fiction",
        "এক কাল্পনিক মহাজাগতিক কাহিনিতে এমন এক জিনের সন্ধান মেলে, যার শক্তি নিয়ে প্রাচীন পুঁথিতে অসম্ভব সব দাবি লেখা আছে।",
        """নিষিদ্ধ গ্রন্থাগারের পুঁথিটি রাত বারোটায় নিজে থেকেই খুলে গেল। তাতে লেখা: “শক্তির সীমা নিয়ে যারা অহংকার করে, তারা অজানাকে ভয় পায়।” গবেষক নাদিয়া এক নির্জন উপত্যকায় পৌঁছে দেখল আলোকবিন্দুর মাঝে দাঁড়িয়ে আছে এক রহস্যময় জিন। সে বলল, “আমাকে শক্তিশালী বলো না; শক্তির সত্য জানে সে-ই, যে তা ব্যবহার না করার সাহস রাখে।”"""),
    Story("সাত রাজ্যের অমর জিনের রহস্য", "Adventure • Immortal Jinn",
        "অমরত্বের রহস্য খুঁজতে গিয়ে তিন বন্ধু আবিষ্কার করে সাত দরজার পেছনে লুকিয়ে থাকা অসমাপ্ত প্রতিজ্ঞা।",
        """পাহাড়ের গুহায় সাতটি দরজা—বালি, আগুন, জল, বাতাস, ছায়া, আলো ও সময়ের চিহ্ন আঁকা। তিন বন্ধু খুঁজছিল অমর জিনের কিংবদন্তি। প্রতিটি দরজার ওপারে তাদের দিতে হলো একটি সত্য স্বীকারের মূল্য। শেষ দরজার ওপাশ থেকে কণ্ঠ ভেসে এল: “অমরত্ব মানে অনন্ত জীবন নয়; কখনো কখনো তা অনন্ত অপেক্ষা।”""")
)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("earntaka", MODE_PRIVATE)
        setContent {
            var coins by remember { mutableIntStateOf(prefs.getInt("coins", 0)) }
            var unlocked by remember { mutableStateOf(prefs.getStringSet("unlocked", emptySet())?.toSet() ?: emptySet()) }
            var selected by remember { mutableStateOf<Int?>(null) }
            var wallet by remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFE7B85C))) {
                Scaffold(topBar = {
                    TopAppBar(title = { Text("EARN TAKA", fontWeight = FontWeight.ExtraBold) },
                        actions = { TextButton(onClick = { wallet = true }) { Text("🪙 $coins") } })
                }) { pad ->
                    when {
                        wallet -> Wallet(coins) { wallet = false }
                        selected != null -> {
                            val id = selected!!
                            StoryPage(stories[id], unlocked.contains(id.toString()), { selected = null }) {
                                // Demo-only: replace with server-verified coin debit.
                                if (coins >= 10) {
                                    coins -= 10
                                    unlocked = unlocked + id.toString()
                                    prefs.edit().putInt("coins", coins).putStringSet("unlocked", unlocked).apply()
                                }
                            }
                        }
                        else -> Home(coins, unlocked, { wallet = true }, { selected = it })
                    }
                }
            }
        }
    }
}

@Composable
fun Home(coins: Int, unlocked: Set<String>, openWallet: () -> Unit, openStory: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("রহস্যের এক নতুন জগৎ", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("জিন • ইফরিত • মারিদ • সাত রাজ্যের কাহিনি")
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth().clickable { openWallet() }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("আমার Coin")
                    Text("$coins 🪙", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                }
                Button(onClick = openWallet) { Text("Coin কিনুন") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("গল্পের তালিকা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(stories) { i, story ->
                Card(Modifier.fillMaxWidth().clickable { openStory(i) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(story.title, fontWeight = FontWeight.Bold)
                            Text(story.genre, color = MaterialTheme.colorScheme.primary)
                            Text(story.synopsis, maxLines = 2, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (unlocked.contains(i.toString())) "খোলা" else "🔒 10 🪙")
                    }
                }
            }
        }
    }
}

@Composable
fun Wallet(coins: Int, back: () -> Unit) {
    val packs = listOf(
        "10 Coin" to "$1.01",
        "20 Coin" to "$2.01",
        "30 Coin" to "$3.01",
        "40 Coin" to "$4.01",
        "50 Coin" to "$5.01",
        "90 Coin" to "$9.01"
    )
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = back) { Text("← ফিরে যান") }
        Text("Coin Wallet", style = MaterialTheme.typography.headlineMedium)
        Text("বর্তমান ব্যালেন্স: $coins 🪙", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Text("আপনার পছন্দের Coin প্যাকেজ কিনুন", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        packs.forEach { pack ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(pack.first, fontWeight = FontWeight.Bold)
                        Text(pack.second, color = MaterialTheme.colorScheme.primary)
                    }
                    OutlinedButton(onClick = {}, enabled = false) {
                        Text("Billing setup pending")
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "এই দামগুলো নির্ধারিত প্যাকেজের তালিকা। Google Play Billing ও নিরাপদ purchase verification যুক্ত হলে কেনার বাটন চালু হবে।",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun StoryPage(story: Story, isUnlocked: Boolean, back: () -> Unit, unlock: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = back) { Text("← গল্পের তালিকায় ফিরুন") }
        Text(story.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(story.genre, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        if (isUnlocked) {
            Column(Modifier.verticalScroll(rememberScrollState())) { Text(story.sample, style = MaterialTheme.typography.bodyLarge) }
        } else {
            Text(story.synopsis)
            Spacer(Modifier.height(12.dp))
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("এই গল্পটি Locked")
                    Text("Unlock করতে ১০ Coin লাগবে।")
                    Button(onClick = unlock, enabled = false) { Text("Unlock (Billing setup pending)") }
                    Text("ডেমোতে Coin বা পেমেন্ট কার্যকর নয়।", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
