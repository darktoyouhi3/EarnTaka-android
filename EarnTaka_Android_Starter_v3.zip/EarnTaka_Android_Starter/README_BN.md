# Earn Taka — Android Starter Project

- Package name: `com.earntaka.app`
- Bengali UI, dark + gold theme, no login
- ৫টি supernatural/fantasy গল্পের প্রাথমিক sample
- Coin pack display: 10/$1.01, 20/$2.01, 30/$3.01, 40/$4.01, 50/$5.01, 90/$9.01
- প্রতি গল্প unlock cost: 10 Coin

## মোবাইল থেকে APK build (পরীক্ষার জন্য)
এই প্রজেক্টে `.github/workflows/android-build.yml` আছে। GitHub repository-তে প্রজেক্টের ফাইল আপলোড করে `Actions` থেকে `Build Earn Taka debug APK` workflow চালালে debug APK artifact তৈরি হবে।

## গুরুত্বপূর্ণ
এটি এখনো Play Store release-ready নয়। Debug APK শুধু ফোনে install করে UI পরীক্ষা করার জন্য; Play Store-এ debug APK upload করা যাবে না। Release-এর জন্য signed AAB, release keystore, Google Play Billing integration, product IDs, purchase verification, পূর্ণ ৫টি গল্প এবং Play Console testing/policy checks প্রয়োজন। Billing buttons এখনো disabled; কোনো আসল payment হয় না।

Google Play-তে digital coins/story unlock বিক্রির জন্য Play Billing ব্যবহার করতে হবে। No-login/local-only balance নিরাপদ purchase restore দেয় না; production-এ purchase token যাচাই ও restore design করতে হবে।
